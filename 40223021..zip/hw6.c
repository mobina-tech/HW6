#include<stdio.h>    // Mobina Teromideh   40223021
#include<math.h>
int tedad;

void solver(float a,float b,float c, float*ans1, float*ans2);
int main()
{
    float a,b,c;
    
    printf("Enter a:");
    scanf("%f",&a);
    printf("Enter b:");
    scanf("%f",&b);
    printf("Enter c:");
    scanf("%f",&c);
    float x1,x2;
    float *ans1=&x1;
    float *ans2=&x2;
    solver(a,b,c,ans1,ans2);

    if((a==0.0)&&(b==0.0))
    ;//program will stop 
    else
    {
        if(tedad==2)
        {
           printf("tedad is %d, x1=%f\t x2=%f  ",tedad,*ans1,*ans2);
        }
        if(tedad==1)// when a=0 or delta=0
           printf("tedad is %d , x1=%f",tedad,*ans1);

    }


return 0;
}//main

void solver(float a ,float b,float c,float*ans1,float*ans2)
{

    if((a==0.0)&&(b==0.0))// it is going to be c=0 
      printf("Wrong input!");
    else if(a==0.0)// it is line :bx+c=0  because a=0
    {
        tedad=1;
        
        *ans1= ((-c)/b);//root of line
    }
    else
    {
        if(((b*b)-(4*a*c))<0.0)//delta <0
           printf("This equation has no real roots");
        else
        {
            float f=(b*b)-(4*a*c);
            
            
           *ans1=((-b)+(float)sqrt(f))/(2*a);
           *ans2=((-b)-(float)sqrt(f))/(2*a);
        
            
            if(f==0)// delta=0  --> x1=x2
            {
                
                tedad=1;
                 *ans1=*ans2= (-b)/(2*a);
            }
           else
            {
                
                tedad=2;
                *ans1;
                *ans2; 
                      
            }
        } 
    }  
}